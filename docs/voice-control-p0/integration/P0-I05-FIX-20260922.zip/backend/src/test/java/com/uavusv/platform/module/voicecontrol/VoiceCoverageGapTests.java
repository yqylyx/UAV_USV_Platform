package com.uavusv.platform.module.voicecontrol;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.Arguments;
import java.util.Set;
import java.util.stream.Stream;

/** Named coverage gaps. H2/service fixtures; these do not constitute Unity browser evidence. */
class VoiceCoverageGapTests extends VoiceControlTests {
    static Stream<Arguments> actionStates() {
        return Stream.of("START","PAUSE","RESUME","STOP").flatMap(action ->
            Stream.of("PREPARED","PREVIEW","RUNNING","PAUSED","STOPPED","COMPLETED","CANCELLED","FAILED","LOST")
                .map(state -> Arguments.of(action,state)));
    }
    @ParameterizedTest @MethodSource("actionStates")
    void actionStateMatrix(String action,String state) {
        s.locked(() -> {var ctx=s.get("voice_runtime_context",ref());ctx.put("state",state);s.save("voice_runtime_context",ctx);return null;});
        boolean allowed=switch(action){
            case "START" -> Set.of("PREPARED","PREVIEW").contains(state);
            case "PAUSE" -> state.equals("RUNNING");
            case "RESUME" -> state.equals("PAUSED");
            default -> Set.of("PREPARED","PREVIEW","RUNNING","PAUSED").contains(state);
        };
        if(allowed) assertNotNull(proposal(action));
        else error("INVALID_STATE",()->proposal(action));
        assertEquals(0,sent.size());
    }
    @ParameterizedTest @ValueSource(strings={"VIEWER","OPERATOR","DISABLED"})
    void revocationRejectsCachedConfirmationAndNewWrites(String mode) {
        var p=proposal("PAUSE");String key=VoiceJson.uuid();
        var first=app.confirm(p.path("proposalId").asText(),key,confirmation(p));
        if(mode.equals("DISABLED")) s.jdbc.update("UPDATE app_user SET enabled=false WHERE id=1");
        else s.jdbc.update("UPDATE app_user SET role=? WHERE id=1",mode);
        error("FORBIDDEN",()->app.confirm(p.path("proposalId").asText(),key,confirmation(p)));
        error("FORBIDDEN",()->app.createProposal(VoiceJson.uuid(),request("STOP")));
        error("FORBIDDEN",()->app.cancel(p.path("proposalId").asText(),VoiceJson.uuid(),confirmation(p)));
        worker.tick();
        assertEquals("INVALIDATED",s.get("voice_execution",execution(first.data()).path("executionId").asText()).path("state").asText());
        assertEquals(0,sent.size());assertEquals(1,count("voice_execution"));
    }
    @ParameterizedTest @ValueSource(strings={"QUEUED","DISPATCHED","ACCEPTED","SUCCEEDED"})
    void restartRecoversEachDispatchStageWithoutReplay(String stage) {
        var p=proposal("PAUSE");var e=execution(confirm(p));
        if(!stage.equals("QUEUED")) worker.tick();
        if(stage.equals("ACCEPTED")) result(e,"ACCEPTED",1);
        if(stage.equals("SUCCEEDED")) result(e,"SUCCEEDED",2);
        var pending=proposal("STOP");int writes=sent.size();
        r.channels.clear();worker.recover();worker.tick();worker.recover();worker.tick();
        assertEquals("LOST",app.context(ref()).path("state").asText());
        assertEquals("INVALIDATED",s.get("voice_proposal",pending.path("proposalId").asText()).path("status").asText());
        var actual=app.execution(e.path("executionId").asText());
        assertEquals(stage.equals("QUEUED")?"INVALIDATED":stage.equals("SUCCEEDED")?"SUCCEEDED":"TIMED_OUT",actual.path("state").asText());
        if(stage.equals("DISPATCHED")||stage.equals("ACCEPTED"))assertEquals("UNKNOWN",actual.path("outcome").asText());
        assertEquals(writes,sent.size());assertEquals(1,count("voice_execution"));
    }
    @Test void oldBindingAndGenerationReportsCannotRefreshScene() {
        var bind=presentation.bind(ref(),VoiceJson.uuid(),j.object().put("runtimeGeneration",gen()).putNull("expectedBindingId"));
        var body=j.object().put("runtimeGeneration",gen()).put("bindingId",bind.path("bindingId").asText()).put("kind","SCENE_READY").putNull("executionId");
        var q=presentation.challenge(ref(),VoiceJson.uuid(),body);
        var report=body.deepCopy();report.set("requestId",q.path("requestId"));report.set("sequence",q.path("sequence"));report.put("frameSequence",1).put("applied",true);
        var replacement=presentation.bind(ref(),VoiceJson.uuid(),j.object().put("runtimeGeneration",gen()).put("expectedBindingId",bind.path("bindingId").asText()));
        error("CONTEXT_CHANGED",()->presentation.report(ref(),VoiceJson.uuid(),report));
        report.put("bindingId",replacement.path("bindingId").asText()).put("runtimeGeneration",VoiceJson.uuid());
        error("GENERATION_MISMATCH",()->presentation.report(ref(),VoiceJson.uuid(),report));
        assertFalse(app.context(ref()).path("sceneReady").asBoolean());
        assertEquals(0,count("voice_execution"));assertEquals(0,sent.size());
    }
    @Test void lateAcceptedNeverRollsBackSuccess() {
        var e=execution(confirm(proposal("PAUSE")));worker.tick();result(e,"SUCCEEDED",2);result(e,"ACCEPTED",1);
        assertEquals("SUCCEEDED",app.execution(e.path("executionId").asText()).path("state").asText());
        assertEquals("PAUSED",app.context(ref()).path("state").asText());assertEquals(1,sent.size());
    }

    @ParameterizedTest @ValueSource(strings={"ownerUserId","runId","executionBackend","requiresConfirmation"})
    void dangerousUnknownProposalFieldsAreRejected(String field) {
        var body=request("PAUSE");body.put(field,false);
        error("INVALID_REQUEST",()->app.createProposal(VoiceJson.uuid(),body));
        assertEquals(0,count("voice_proposal"));assertEquals(0,count("voice_execution"));assertEquals(0,sent.size());
    }
    @ParameterizedTest @ValueSource(strings={"version","hash"})
    void wrongPlanNeverCreatesExecution(String field) {
        var p=proposal("PAUSE");var body=confirmation(p);
        if(field.equals("version"))body.put("expectedPlanVersion",2);else body.put("expectedPlanHash","0".repeat(64));
        var before=s.get("voice_proposal",p.path("proposalId").asText()).deepCopy();
        var failure=assertThrows(VoiceFailure.class,()->app.confirm(p.path("proposalId").asText(),VoiceJson.uuid(),body));
        assertEquals(field.equals("version")?400:409,failure.status);
        assertEquals(field.equals("version")?"INVALID_REQUEST":"PLAN_MISMATCH",failure.code);
        assertEquals(before,s.get("voice_proposal",p.path("proposalId").asText()));
        assertEquals(0,count("voice_execution"));assertEquals(0,count("voice_outbox"));assertEquals(0,sent.size());
    }
    @ParameterizedTest @ValueSource(longs={29999,30000,30001})
    void proposalExpiryAtEachMillisecondBoundary(long age) {
        var p=proposal("PAUSE");t.advance(age);heartbeat("RUNNING",3,2);
        if(age<30000)assertNotNull(confirm(p));else {
            error("PROPOSAL_EXPIRED",()->confirm(p));
            assertEquals("EXPIRED",app.proposal(p.path("proposalId").asText()).path("status").asText());
            assertEquals(0,count("voice_execution"));
        }
        assertEquals(0,sent.size());
    }
    @ParameterizedTest @ValueSource(strings={"legacy","subset"})
    void unsupportedProtocolOrActionNeverWrites(String mode) {
        s.locked(()->{var ctx=s.get("voice_runtime_context",ref());
            if(mode.equals("legacy"))ctx.put("protocolVersion","legacy");else ctx.putArray("capabilities").add("STOP");
            s.save("voice_runtime_context",ctx);return null;});
        error(mode.equals("legacy")?"PROTOCOL_UNSUPPORTED":"UNSUPPORTED_CAPABILITY",()->proposal("PAUSE"));
        assertEquals(0,count("voice_execution"));assertEquals(0,sent.size());
    }
    @ParameterizedTest @ValueSource(strings={"START","PAUSE","RESUME","STOP"})
    void staleSceneGatesOnlyStartAndResume(String action) {
        String state=action.equals("START")?"PREPARED":action.equals("RESUME")?"PAUSED":"RUNNING";
        heartbeat(state,4,2);t.advance(10001);heartbeat(state,4,3);
        if(action.equals("START")||action.equals("RESUME"))error("SCENE_NOT_READY",()->proposal(action));
        else assertNotNull(proposal(action));
    }
    @Test void duplicateCancelAndConfirmedCancelNeverWrite() {
        var p=proposal("PAUSE");var id=p.path("proposalId").asText();var key=VoiceJson.uuid();
        app.cancel(id,key,confirmation(p));app.cancel(id,key,confirmation(p));app.cancel(id,VoiceJson.uuid(),confirmation(p));
        assertEquals("CANCELLED",app.proposal(id).path("status").asText());assertEquals(0,count("voice_execution"));
        var another=proposal("STOP");confirm(another);
        error("ALREADY_CONFIRMED",()->app.cancel(another.path("proposalId").asText(),VoiceJson.uuid(),confirmation(another)));
        assertEquals(0,sent.size());
    }
    @ParameterizedTest @ValueSource(strings={"before_write","after_write"})
    void committedSendingFailureDoesNotRetry(String window) {
        r.attach(ref(),gen(),n -> {
            if(n.path("kind").asText().equals("STATUS_QUERY"))return;
            assertEquals("SENDING",s.jdbc.queryForObject("SELECT status FROM voice_outbox",String.class));
            if(window.equals("after_write"))sent.add(n);
            throw new IllegalStateException("injected "+window);
        },alive::get);
        r.channel(ref()).heartbeatNanos=t.nanos();
        var e=execution(confirm(proposal("PAUSE")));worker.tick();worker.tick();
        assertEquals("UNCERTAIN",s.jdbc.queryForObject("SELECT status FROM voice_outbox",String.class));
        assertEquals("TIMED_OUT",app.execution(e.path("executionId").asText()).path("state").asText());
        assertEquals("UNKNOWN",app.execution(e.path("executionId").asText()).path("outcome").asText());
        assertEquals(window.equals("after_write")?1:0,sent.stream().filter(n->n.path("kind").asText().equals("COMMAND")).count());
    }
    @Test void receiptPersistenceFailureIsBufferedAndReconciled() {
        var e=execution(confirm(proposal("PAUSE")));worker.tick();
        s.jdbc.execute("ALTER TABLE voice_command_event RENAME TO temporarily_unavailable_event");
        try {
            result(e,"SUCCEEDED",2);worker.tick();
            assertEquals("DISPATCHED",app.execution(e.path("executionId").asText()).path("state").asText());
            assertEquals(1,sent.size());
        } finally {s.jdbc.execute("ALTER TABLE temporarily_unavailable_event RENAME TO voice_command_event");}
        worker.tick();assertEquals("SUCCEEDED",app.execution(e.path("executionId").asText()).path("state").asText());
        assertEquals(1,count("voice_command_event"));assertEquals(1,sent.size());
    }
    @ParameterizedTest @ValueSource(strings={"ACK","RESULT"})
    void exactCommandTimeoutBoundary(String phase) {
        var e=execution(confirm(proposal("PAUSE")));worker.tick();
        if(phase.equals("RESULT"))result(e,"ACCEPTED",1);
        t.advance(phase.equals("ACK")?4999:14999);worker.tick();
        assertNotEquals("TIMED_OUT",app.execution(e.path("executionId").asText()).path("state").asText());
        t.advance(1);worker.tick();assertEquals("TIMED_OUT",app.execution(e.path("executionId").asText()).path("state").asText());
        result(e,"SUCCEEDED",2);assertEquals("SUCCEEDED",app.execution(e.path("executionId").asText()).path("state").asText());
        assertFalse(app.execution(e.path("executionId").asText()).path("timedOutAt").isNull());
        assertEquals(1,sent.stream().filter(n->n.path("kind").asText().equals("COMMAND")).count());
    }
    @Test void twoWorkersOnlyClaimOneOutbox() throws Exception {
        confirm(proposal("PAUSE"));var second=new VoiceDispatcher(s,j,t,r);
        var gate=new java.util.concurrent.CountDownLatch(1);var pool=java.util.concurrent.Executors.newFixedThreadPool(2);
        try {
            var one=pool.submit(()->{gate.await();worker.tick();return true;});
            var two=pool.submit(()->{gate.await();second.tick();return true;});gate.countDown();
            one.get(10,java.util.concurrent.TimeUnit.SECONDS);two.get(10,java.util.concurrent.TimeUnit.SECONDS);
        } finally {pool.shutdownNow();}
        assertEquals(1,sent.size());assertEquals(1,count("voice_outbox"));
    }

    @org.junit.jupiter.api.RepeatedTest(100)
    void confirmConcurrencyHundredRounds() throws Exception {
        concurrentConfirmDifferentKeysHasOneExecutionAndOneWrite();
    }
    @org.junit.jupiter.api.RepeatedTest(100)
    void confirmCancelHundredRounds() throws Exception {
        concurrentConfirmCancelHasOneWinner();worker.tick();
        assertTrue(sent.size()<=1);assertEquals(count("voice_execution"),sent.size());
    }
    @ParameterizedTest @ValueSource(strings={"TIMED_OUT","FAILED","REJECTED","INVALIDATED"})
    void unsuccessfulExecutionCannotAcquireFrameChallenge(String state) {
        var e=execution(confirm(proposal("PAUSE")));
        s.locked(()->{var stored=s.get("voice_execution",e.path("executionId").asText());stored.put("state",state).put("action","START");s.save("voice_execution",stored);return null;});
        var bind=presentation.bind(ref(),VoiceJson.uuid(),j.object().put("runtimeGeneration",gen()).putNull("expectedBindingId"));
        var body=j.object().put("runtimeGeneration",gen()).put("bindingId",bind.path("bindingId").asText()).put("kind","FRAME_APPLIED").put("executionId",e.path("executionId").asText());
        error("INVALID_STATE",()->presentation.challenge(ref(),VoiceJson.uuid(),body));
        assertEquals(state,app.execution(e.path("executionId").asText()).path("state").asText());assertEquals(0,sent.size());
    }
    @ParameterizedTest @ValueSource(longs={2,3,5,6})
    void presentationFrameBounds(long frame) {
        heartbeat("PREPARED",4,2);var e=execution(confirm(proposal("START")));worker.tick();
        r.frame(ref(),gen(),j.read("{\"sequence\":5,\"agents\":[{\"deviceCode\":\"UAV-001\"},{\"deviceCode\":\"USV-001\"}]}"));
        var result=event("COMMAND_RESULT");result.set("commandId",e.path("commandId"));
        result.put("eventSequence",2).put("status","SUCCEEDED").put("runtimeState","RUNNING").put("stateVersion",5).put("lastFrameSequence",3).putNull("errorCode");
        result.putArray("affectedDeviceCodes").add("UAV-001").add("USV-001");worker.receive(ref(),gen(),result);
        var bind=presentation.bind(ref(),VoiceJson.uuid(),j.object().put("runtimeGeneration",gen()).putNull("expectedBindingId"));
        var body=j.object().put("runtimeGeneration",gen()).put("bindingId",bind.path("bindingId").asText()).put("kind","FRAME_APPLIED").put("executionId",e.path("executionId").asText());
        var q=presentation.challenge(ref(),VoiceJson.uuid(),body);var report=body.deepCopy();report.set("requestId",q.path("requestId"));report.set("sequence",q.path("sequence"));report.put("frameSequence",frame).put("applied",true);
        if(frame<3)error("CONTEXT_CHANGED",()->presentation.report(ref(),VoiceJson.uuid(),report));
        else if(frame>5)error("INVALID_REQUEST",()->presentation.report(ref(),VoiceJson.uuid(),report));
        else presentation.report(ref(),VoiceJson.uuid(),report);
        var actual=app.execution(e.path("executionId").asText());assertEquals("SUCCEEDED",actual.path("state").asText());
        assertEquals(frame>=3&&frame<=5?"REPORTED_APPLIED":"PENDING",actual.path("presentationStatus").asText());
        assertEquals(1,sent.size());
    }
    @ParameterizedTest @ValueSource(strings={"generation","members"})
    void dispatchRechecksChangedIdentityAndMembership(String change) {
        var e=execution(confirm(proposal("PAUSE")));
        if(change.equals("generation"))s.locked(()->{var ctx=s.get("voice_runtime_context",ref());ctx.put("runtimeGeneration",VoiceJson.uuid());s.save("voice_runtime_context",ctx);return null;});
        else r.frame(ref(),gen(),j.read("{\"sequence\":2,\"agents\":[{\"deviceCode\":\"OTHER\"}]}"));
        worker.tick();assertEquals("INVALIDATED",app.execution(e.path("executionId").asText()).path("state").asText());assertEquals(0,sent.size());
    }
}
